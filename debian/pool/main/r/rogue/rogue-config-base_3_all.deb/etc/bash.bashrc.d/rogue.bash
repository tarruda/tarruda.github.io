alias ls='ls --color=auto'
alias ll='ls --color=auto -lh'
alias la='ls --color=auto -lah'

alias rm='rm -i'
alias cp='cp -i'
alias mv='mv -i'

if [[ "`id -u`" -ne 0 ]]; then
	alias poweroff='/sbin/poweroff'
	alias reboot='/sbin/reboot'
	alias ifconfig='/sbin/ifconfig'
	# when not root, always use su --login so that /sbin dirs are added to PATH.
	alias su='su --login'
fi

HISTSIZE=20000
HISTFILESIZE=$HISTSIZE
HISTCONTROL=ignoreboth

generate-colors-for-term() {
	local cache_dir="$HOME/.cache/prompt-terminal-colors"
	local colors_script="$cache_dir/$TERM.colors.sh"
	if [[ -e "$colors_script" ]]; then
		echo "$colors_script"
		return
	fi
	local tput_term
	if tput setaf > /dev/null 2>&1; then
		tput_term="$TERM"
	else
		tput_term="ansi"
	fi
	local colors_script="$cache_dir/$tput_term.colors.sh"
	if [[ -e "$colors_script" ]]; then
		echo "$colors_script"
		return
	fi
	mkdir -p "$cache_dir"
	cat > $colors_script <<- EOF
	local reset="\["\$'$(tput -T $tput_term sgr0 | sed 's/\x1b/\\E/g')'"\]"
	local red="\["\$'$(tput -T $tput_term setaf 1 | sed 's/\x1b/\\E/g')'"\]"
	local green="\["\$'$(tput -T $tput_term setaf 2 | sed 's/\x1b/\\E/g')'"\]"
	local yellow="\["\$'$(tput -T $tput_term setaf 3 | sed 's/\x1b/\\E/g')'"\]"
	local blue="\["\$'$(tput -T $tput_term setaf 4 | sed 's/\x1b/\\E/g')'"\]"
	local red2="\["\$'$(tput -T $tput_term setaf 9 | sed 's/\x1b/\\E/g')'"\]"
	local cnorm="\["\$'$(tput -T $tput_term cnorm | sed 's/\x1b/\\E/g')'"\]"
	$(dircolors)
	EOF
	echo "$colors_script"
}

generate-prompt-and-colors() {
	local colors_script="$(generate-colors-for-term)"
	source "$colors_script"
	local user="\u"
	local host="\h"
	local directory="\w"
	local ps1="\$(rv=\$?; [[ \"\$rv\" != \"0\" ]] && echo -n \"${red2}\$rv${reset} \")"
	ps1+="${user}${yellow}@${reset}${host} ${blue}::${reset} ${directory} "
	if [[ "$UID" == "0" ]]; then
		ps1+="${red}#${reset} "
	else
		ps1+="${green}\$${reset} "
	fi
	PS1="$ps1${cnorm}"
}

generate-prompt-and-colors
unset -f generate-prompt-and-colors
unset -f generate-colors-for-term

if ! shopt -oq posix; then
	if [[ -f /usr/share/bash-completion/bash_completion ]]; then
		. /usr/share/bash-completion/bash_completion
	elif [[ -f /etc/bash_completion ]]; then
		. /etc/bash_completion
	fi
fi
