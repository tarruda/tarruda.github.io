include firefox-esr.profile

blacklist ${HOME}/.mozilla

noblacklist ${HOME}/.syncthing-gui

mkdir ${HOME}/.syncthing-gui

whitelist ${HOME}/.syncthing-gui
whitelist ${RUNUSER}/syncthing-gui

net none
