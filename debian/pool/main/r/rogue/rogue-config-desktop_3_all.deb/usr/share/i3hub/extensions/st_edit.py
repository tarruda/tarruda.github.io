from i3hub import extension, listen

@extension()
class StEdit(object):
    def __init__(self, i3):
        self._i3 = i3

    @listen('i3::window')
    async def on_window(self, event, arg):
        container = arg['container']
        props = container.get('window_properties')
        is_edit_window = props and (
                props.get('class') == 'St' and props.get('instance') == 'st-edit')
        if not is_edit_window:
            return
        if arg['change'] == 'new':
            await self.on_new_st_edit_window(container)
        elif arg['change'] == 'close':
            await self.on_close_st_edit_window(container)

    async def on_new_st_edit_window(self, container):
        print('new st-edit window, changing layout to tabbed')
        await self._i3.command('layout tabbed')

    async def on_close_st_edit_window(self, container):
        print('closed st-edit window, moving to parent')
        await self._i3.command('move up')
