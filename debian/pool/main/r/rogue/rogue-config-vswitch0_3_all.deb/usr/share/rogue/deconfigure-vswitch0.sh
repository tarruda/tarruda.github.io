#!/bin/sh -e

systemctl stop vswitch0-dnsmasq.service
systemctl disable vswitch0-dnsmasq.service
ufw delete allow in on vswitch0 from any port 68 to any port 67 proto udp
ufw delete allow in on vswitch0 to any port 53
ufw route delete allow in on vswitch0
ufw route delete allow out on vswitch0
nat_section_file=/usr/share/rogue/nat-masquerade.txt
first_line="$(head -n1 $nat_section_file)"
line_count="$(wc -l $nat_section_file | awk '{print $1}')"
sed -e "/${first_line}/,$(( line_count + 1 ))d" -i /etc/ufw/before.rules
