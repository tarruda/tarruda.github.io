#!/bin/sh -e

systemctl disable dnsmasq.service
systemctl enable vswitch0-dnsmasq.service
ufw allow in on vswitch0 from any port 68 to any port 67 proto udp
ufw allow in on vswitch0 to any port 53
ufw route allow in on vswitch0
ufw route allow out on vswitch0

nat_section_file=/usr/share/rogue/nat-masquerade.txt
first_line="$(head -n1 $nat_section_file)"
if ! grep -q "$first_line" /etc/ufw/before.rules; then
	sed -e "1r $nat_section_file" -i /etc/ufw/before.rules
fi

ufw enable
