from .nvr import main
