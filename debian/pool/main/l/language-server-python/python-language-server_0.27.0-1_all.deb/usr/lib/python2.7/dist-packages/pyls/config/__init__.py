# Copyright 2017 Palantir Technologies, Inc.
