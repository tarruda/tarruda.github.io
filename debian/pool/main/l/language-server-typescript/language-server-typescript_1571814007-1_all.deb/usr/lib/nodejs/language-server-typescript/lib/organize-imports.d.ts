import * as lsp from 'vscode-languageserver';
export declare function provideOrganizeImports(file: string, context: lsp.CodeActionContext, result: (lsp.Command | lsp.CodeAction)[]): void;
//# sourceMappingURL=organize-imports.d.ts.map