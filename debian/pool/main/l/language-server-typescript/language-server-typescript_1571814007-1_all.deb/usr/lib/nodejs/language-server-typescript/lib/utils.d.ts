export declare class Deferred<T> {
    private operation;
    private timer;
    constructor(operation: string, timeout?: number);
    resolve: (value?: T) => void;
    reject: (err?: any) => void;
    promise: Promise<T>;
}
export declare function getTsserverExecutable(): string;
export declare function isWindows(): boolean;
//# sourceMappingURL=utils.d.ts.map