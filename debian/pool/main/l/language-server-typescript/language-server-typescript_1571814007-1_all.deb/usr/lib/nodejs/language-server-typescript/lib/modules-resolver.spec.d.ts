export {};
//# sourceMappingURL=modules-resolver.spec.d.ts.map