export declare class Deferred<T> {
    private operation;
    private timer;
    constructor(operation: string, timeout?: number);
    cancel(): void;
    resolve: (value?: T) => void;
    reject: (err?: unknown) => void;
    promise: Promise<T>;
}
export declare function getTsserverExecutable(): string;
//# sourceMappingURL=utils.d.ts.map