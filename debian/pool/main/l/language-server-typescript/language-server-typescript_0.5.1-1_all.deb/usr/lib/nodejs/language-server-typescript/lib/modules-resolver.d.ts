export declare function findPathToModule(dir: string, moduleName: string): string | undefined;
//# sourceMappingURL=modules-resolver.d.ts.map