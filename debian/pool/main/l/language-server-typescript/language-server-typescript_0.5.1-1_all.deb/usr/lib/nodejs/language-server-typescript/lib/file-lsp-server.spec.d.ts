export {};
//# sourceMappingURL=file-lsp-server.spec.d.ts.map