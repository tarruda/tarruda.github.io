export {};
//# sourceMappingURL=tsp-client.spec.d.ts.map