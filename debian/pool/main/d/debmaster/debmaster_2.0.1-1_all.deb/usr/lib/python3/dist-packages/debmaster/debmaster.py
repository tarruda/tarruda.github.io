#!/usr/bin/env python3
import argparse
import os
import pathlib
import sys
import tempfile

try:
    from xdg.BaseDirectory import xdg_cache_home as XDG_CACHE_HOME
except ImportError:
    XDG_CACHE_HOME = os.path.expanduser('~/.cache')

from ush import ProcessError
from ush.sh import lsb_release, getent, git, dpkg

from .generate import generate, iter_packages
from .build import build
from .repo import update_repository
from .misc import debug


def parse_args(argv):
    # setup some defaults that can be overriden via command line
    # cache directory
    if not os.environ.get('DEBMASTER_CACHE', None):
        os.environ['DEBMASTER_CACHE'] = '{}/debmaster'.format(XDG_CACHE_HOME)
    # distribution
    distribution = list(
            lsb_release('-i'))[0].split(':')[1].strip().lower()
    # release
    release = list(lsb_release('-c'))[0].split()[1]
    # architecture
    architecture = list(dpkg('--print-architecture'))[0]
    # author email
    author_email = os.environ.get('DEBEMAIL', None)
    if author_email is None:
        try:
            author_email = list(git('config', 'user.email'))[0]
        except ProcessError:
            pass
    # author name
    author_name = os.environ.get('DEBFULLNAME', None)
    if author_name is None:
        try:
            author_name = list(git('config', 'user.name'))[0]
        except ProcessError:
            pass
    if author_name is None:
        try:
            author_name = list(getent('passwd', 'username'))[0].split(':')[4]
        except ProcessError:
            pass
    #
    parser = argparse.ArgumentParser()
    parser.add_argument('--directory', '-C', default=os.getcwd(),
            help='Run as if started from directory')
    parser.add_argument('--cache-root', default=os.environ['DEBMASTER_CACHE'],
            help='Cache directory root')
    parser.add_argument('--print-outdated', default=False, action='store_true',
            help='Print name of outdated packages and exit')
    parser.add_argument('-n', '--name', default=author_name,
            help='Name of the package author')
    parser.add_argument('-e', '--email', default=author_email,
            help='Email of the package author')
    parser.add_argument('-d', '--distribution', default=distribution,
            help='Distribution name')
    parser.add_argument('-r', '--release', default=release,
            help='Codename of the release')
    parser.add_argument('-a', '--architecture', default=architecture,
            help='Build architecture')
    parser.add_argument('-v', '--verbose', default=False, action='store_true',
            help='Show more output to help debugging')
    parser.add_argument('-b', '--build', default=False, action='store_true',
            help='Build outdated packages using pbuilder')
    parser.add_argument('--in-pbuilder', default=False, action='store_true',
            help='Used internally to generate source packages with pbuilder.')
    parser.add_argument('-o', '--output-repository',
            default='debmaster-out', help='Location of the output repository')
    parser.add_argument('-s', '--sign-key',
            default=os.getenv('GPGKEY') or None,
            help='GPG key used to sign the reprepro release')
    parser.add_argument('--add-sources', default=False, action='store_true',
            help='Add source packages to the output repository')
    parser.add_argument('--packages', default='*',
            help='Specify a subset of packages configurations to process')
    args = parser.parse_args(argv)
    os.environ['DEBEMAIL'] = args.email
    os.environ['DEBFULLNAME'] = args.name
    return args


def main():
    args = parse_args(sys.argv[1:])
    with tempfile.TemporaryDirectory(prefix='debmaster-') as top_tmp_dir:
        top_tmp_dir = pathlib.Path(top_tmp_dir)
        cache_dir = pathlib.Path(args.cache_root)
        if args.print_outdated:
            for outdated, _, package_dir, config in iter_packages(
                    args, cache_dir, args.directory, top_tmp_dir):
                if outdated:
                    print(config['package']['name'], package_dir)
            return
        debug('(re)generating source packages')
        packages = list(generate(args, cache_dir, args.directory, top_tmp_dir))
        if packages and args.build:
            debug('building...')
            build(args, cache_dir, packages, top_tmp_dir)
            debug('updating {}'.format(args.output_repository))
            update_repository(args, packages)


if __name__ == '__main__':
    sys.exit(main())

