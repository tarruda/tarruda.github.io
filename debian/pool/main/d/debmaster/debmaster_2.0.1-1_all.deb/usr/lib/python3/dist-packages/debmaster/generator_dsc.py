import collections
import os
import re
import urllib

from ush import NULL
from ush.sh import apt, mv, dpkg_source, rm, bash, dget

from .config import cset
from .rules import parse_rules, ensure_rules
from .control import parse_control, stringify_control, ensure_control
from .download import ensure_download_cache_dir, file_already_downloaded
from .generator_common import record_changes, CommonGenerator
from .misc import run_script


SPLITTER = re.compile(r'\d+|[^\d]+')
def parse_version(version):
    """Parse a debian version string for comparison purposes.

    Splits a debian source package version into a tuple of numeric and
    non-numeric components. such tuple can be compared to determine which
    version is the highest.

    >>> v1 = '2:1.19.2-1+deb9u4'
    >>> parse_version(v1)
    (2, ':', 1, '.', 19, '.', 2, '-', 1, '+deb', 9, 'u', 4)
    >>> v2 = '2:1.19.2-1+deb9u12'
    >>> parse_version(v2)
    (2, ':', 1, '.', 19, '.', 2, '-', 1, '+deb', 9, 'u', 12)
    >>> v1 < v2
    False
    >>> parse_version(v1) < parse_version(v2)
    True
    """
    def parser(version):
        for piece in SPLITTER.finditer(version):
            try:
                yield int(piece.group(0))
            except ValueError:
                yield piece.group(0)
    return tuple(parser(version))


def get_source_dsc(source_package):
    # The `apt showsrc` command will display the dsc contents for each matching
    # source package. Since more than one version can be available, we parse
    # the dsc contents, sort by the "Version" key and take the latest entry
    # (this is what `apt source` will download).
    source_control_entries = sorted(parse_control(
        str(apt('showsrc', source_package, stderr=NULL))),
        key=lambda d: parse_version(d['Version']))
    return stringify_control(source_control_entries[-1:]).strip()


def download_apt_source(config, source_package):
    dsc_contents = get_source_dsc(source_package)
    cache_dir = ensure_download_cache_dir(config, dsc_contents)
    dsc_path = list(cache_dir.glob('*.dsc'))
    if not dsc_path:
        rm('-rf', cache_dir)()
        cache_dir.mkdir(exist_ok=True, parents=True) 
        apt('source', '--download-only', source_package, cwd=cache_dir)()
        dsc_path = list(cache_dir.glob('*.dsc'))
    return dsc_path[0]


def pop_existing_sections(config, regexp):
    existing_sections = collections.OrderedDict()
    for section in config.sections():
        if regexp.match(section):
            options = existing_sections[section] = collections.OrderedDict()
            for k, v in config[section].items():
                options[k] = v
            config.remove_section(section)
    return existing_sections


def set_escape_dollar(config, section, option, value):
    config.set(section, option, value.replace('$', '$$'))


def add_section_dict(config, config_section, section_dict):
    for key, value in section_dict.items():
        if not config.has_section(config_section):
            config.add_section(config_section)
        set_escape_dollar(config, config_section, key.lower(), value)


CONTROL_SECTION = re.compile(r'^debian\.control\.')
def edit_control(config):
    existing_sections = pop_existing_sections(config, CONTROL_SECTION)
    if not existing_sections:
        return
    control_file = config.target_dir / 'debian' / 'control'
    parsed_sections = parse_control(control_file.read_text())
    for section in parsed_sections:
        first_key = list(section.keys())[0]
        if first_key == 'Source':
            add_section_dict(config, 'debian.control.source', section)
        else:
            assert first_key == 'Package'
            add_section_dict(config,
                    'debian.control.package.' + section['Package'], section)
    for section, options in existing_sections.items():
        add_section_dict(config, section, options)
    # remove the control file so it will be regenerated
    control_file.unlink()


RULE_SECTION = re.compile(r'^debian\.rules\.')
def edit_rules(config):
    existing_sections = pop_existing_sections(config, RULE_SECTION)
    if not existing_sections:
        return
    rules_file = config.target_dir / 'debian' / 'rules'
    for rule_name, data in parse_rules(rules_file.read_text()).items():
        config_section = 'debian.rules.' + rule_name
        config.add_section(config_section)
        for k in ['prefix', 'deps', 'recipe', 'suffix']:
            v = data.get(k, None)
            if v is not None:
                set_escape_dollar(config, config_section, k, v)
    for section, options in existing_sections.items():
        add_section_dict(config, section, options)
    # remove the rules file so it will be regenerated
    rules_file.unlink()


def download_dsc_url(config, url):
    sha256 = config.get('generator', 'sha256', fallback=None)
    if sha256 is None:
        raise Exception('when specifying dsc url, sha256 is also required')
    cache_dir = ensure_download_cache_dir(config, url)
    dsc_path = cache_dir / os.path.basename(urllib.parse.urlparse(url).path)
    if not file_already_downloaded(dsc_path, sha256):
        dget('--download-only', url, cwd=cache_dir)()
    return dsc_path


class DscGenerator(CommonGenerator):
    def expand_config(self, config):
        pass

    def is_outdated(self, config):
        config.tmp_dir.mkdir(exist_ok=True, parents=True)
        dsc_url = config.get('generator', 'url', fallback=None)
        if dsc_url is None:
            dsc_path = download_apt_source(config, config.get('generator',
                'source-package', fallback=config['package']['name']))
        else:
            dsc_path = download_dsc_url(config, dsc_url)
        config.package_data['dsc-path'] = dsc_path
        return super().is_outdated(config, extra_data=dsc_path.read_text())

    def generate(self, config):
        dpkg_source('-x', '--skip-patches', config.package_data['dsc-path'],
                config.target_dir)()
        run_script(config, 'after-unpack')
        self.copy(config)
        run_script(config, 'after-copy')
        edit_control(config)
        edit_rules(config)
        ensure_control(config)
        ensure_rules(config)
        record_changes(config)
        run_script(config, 'after-debianize')


GENERATOR = DscGenerator()
