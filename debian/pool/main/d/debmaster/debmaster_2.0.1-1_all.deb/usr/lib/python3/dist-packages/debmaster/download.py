import os
import re

from ush import NULL, ProcessError
from ush.sh import echo, git, sha256sum, tar

from .config import cset


def ensure_download_cache_dir(config, hash_data):
    cache_sha256 = str(echo(hash_data) | sha256sum).strip().split()[0]
    sha256_cache_dir = config.cache_dir / 'download' / cache_sha256
    sha256_cache_dir.mkdir(exist_ok=True, parents=True)
    return sha256_cache_dir


def sha256check(path, value):
    (echo('{} {}'.format(value.strip(), path)) | sha256sum('-c', '-') | NULL)()


def file_already_downloaded(path, sha256):
    try:
        sha256check(path, sha256)
        return True
    except ProcessError as e:
        return False


def update_git_repository(cache_dir):
    remote = str(git('-C', cache_dir, 'remote', stderr=os.devnull,
        raise_on_error=False)).strip()
    if not remote:
        return False
    # try to fetch, but allow continuing in case of failure since the
    # repository is already cloned
    git('-C', cache_dir, 'fetch', remote, stderr=NULL, raise_on_error=False)()
    return True


def do_initial_clone(config, url, cache_dir):
    git('clone', '--mirror', url, cache_dir)()
    git_attributes = config.get('upstream', 'git_attributes', fallback=None)
    if git_attributes:
        # if there are git-attributes defined, set in git_dir/info/attributes
        attrs_file = cache_dir / 'info' / 'attributes'
        attrs_file.write_text(git_attributes + '\n')


def download_git(config):
    config.target_dir.mkdir(exist_ok=True, parents=True)
    url = config['upstream']['url']
    treeish = config['upstream']['treeish']
    cache_dir = ensure_download_cache_dir(config, url)
    if not update_git_repository(cache_dir):
        do_initial_clone(config, url, cache_dir)
    # set the upstream version number to the timestamp of the commit
    upstream_version = list(git('--no-pager', 'log', '-1', '--pretty=%at',
        treeish, cwd=cache_dir))[0]
    config['upstream']['version'] = upstream_version
    (git('-C', cache_dir, 'archive', '--format=tar', treeish) |
            tar('xf', '-', cwd=config.target_dir))()


