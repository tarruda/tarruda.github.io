import json
import os
import sys


from ush.sh import sudo, pbuilder


SOURCES_LIST_TEMPLATE = '''
###### Main Repos
deb {mirror} {release} main {extra_components}
deb-src {mirror} {release} main {extra_components}

###### Update Repos
deb {mirror} {release}-updates main {extra_components}
deb-src {mirror} {release}-updates main {extra_components}

###### Security Repos
deb {security_mirror} {security_release} main {extra_components}
deb-src {security_mirror} {security_release} main {extra_components}
'''

SETUP_SOURCES_LIST_TEMPLATE = '''
cat > /etc/apt/sources.list << "EOF"
{sources_list}
EOF
apt update && apt upgrade -y
'''

IMAGE_SETUP_COMMON = 'apt install -y lsb-release git curl gnupg2 devscripts'

HOOK_TEMPLATE = '''#!/bin/bash -e
set -e
set -u
set -o pipefail
{script}
'''


def get_pbuilder_image_path(args, cache_dir, image_name):
    pbuilder_cache_dir = cache_dir / 'pbuilder'
    images_dir = pbuilder_cache_dir / 'images'
    return images_dir / '{}-{}-{}.zst'.format(args.release, args.architecture,
            image_name)


def pbuilder_cmd(args, cache_dir, image_name, mirror):
    def pbuilder_factory(command):
        image_path = get_pbuilder_image_path(args, cache_dir, image_name)
        aptcache_dir = cache_dir / 'pbuilder' / 'aptcache' / args.distribution
        aptcache_dir.mkdir(exist_ok=True, parents=True)
        cmd = pbuilder
        if os.getuid() != 0:
            cmd = sudo('--preserve-env=DEB_BUILD_OPTIONS', 'pbuilder')
        return cmd(command,
                '--compressprog', 'zstd',
                '--aptcache', aptcache_dir,
                '--mirror', mirror,
                '--distribution', args.release,
                '--basetgz', str(image_path))
    return pbuilder_factory


def _get_sources_list_vars(distribution, release):
    if distribution == 'ubuntu':
        mirror = 'http://ubuntu.c3sl.ufpr.br/ubuntu'
        security_mirror = 'http://archive.ubuntu.com/ubuntu'
        security_release = '{}-security'.format(release)
        extra_components = 'universe restricted multiverse'
    else:
        mirror = 'http://deb.debian.org/debian'
        security_mirror = 'http://security.debian.org'
        security_release = '{}/updates'.format(release)
        extra_components = 'main non-free'
    return {
        'mirror': mirror,
        'security_mirror': security_mirror,
        'security_release': security_release,
        'extra_components': extra_components,
        'dist': distribution,
        'release': release
    }


def _ensure_image(args, cache_dir, image_name, architecture, top_tmp_dir,
        hook=''):
    mirror = _get_sources_list_vars(args.distribution, args.release)['mirror']
    pbuilder = pbuilder_cmd(args, cache_dir, image_name, mirror)
    image = get_pbuilder_image_path(args, cache_dir, image_name)
    if image.exists():
        return pbuilder
    image.parent.mkdir(exist_ok=True, parents=True)
    create = pbuilder('create')
    if hook:
        hooks_dir = top_tmp_dir / 'pbuilder-hooks'
        hooks_dir.mkdir(exist_ok=True)
        script = hooks_dir / 'G10setup'
        script.write_text(hook)
        script.chmod(0o700)
        create = create('--hookdir', hooks_dir)
    # generate image with pbuilder
    create()
    return pbuilder


def get_source_image_paths(args, cache_dir):
    image = get_pbuilder_image_path(args, cache_dir, 'source')
    image_metadata = image.with_suffix(image.suffix + '.json')
    return image, image_metadata


def delete_source_image_if_outdated(image, image_metadata, setup_scripts):
    if not image.exists():
        return
    outdated = False
    try:
        metadata = json.loads(image_metadata.read_text())
        image_setup_scripts = set(metadata['setup-scripts'])
        current_setup_scripts = set(setup_scripts)
        # only consider the image outdated if it is a subset of the currently
        # required setup scripts.
        outdated =  image_setup_scripts < current_setup_scripts
    except Exception:
        outdated = True
    if outdated:
        if image_metadata.exists(): image_metadata.unlink()
        image.unlink()


def ensure_source_image(args, cache_dir, top_tmp_dir, setup_scripts):
    fmtargs = _get_sources_list_vars(args.distribution, args.release)
    sources_list = SOURCES_LIST_TEMPLATE.format(**fmtargs)
    setup_sources_list = SETUP_SOURCES_LIST_TEMPLATE.format(
            sources_list=sources_list)
    setup_scripts = [setup_sources_list, IMAGE_SETUP_COMMON] + list(
            setup_scripts)
    image, image_metadata = get_source_image_paths(args, cache_dir)
    delete_source_image_if_outdated(image, image_metadata, setup_scripts)
    rv = _ensure_image(args, cache_dir, 'source', 'amd64', top_tmp_dir,
            hook=HOOK_TEMPLATE.format(script='\n\n'.join(setup_scripts)))
    image_metadata.write_text(json.dumps({'setup-scripts': setup_scripts},
        indent=2))
    return rv


def ensure_build_image(args, cache_dir, top_tmp_dir):
    fmtargs = _get_sources_list_vars(args.distribution, args.release)
    sources_list = SOURCES_LIST_TEMPLATE.format(**fmtargs)
    setup_sources_list = SETUP_SOURCES_LIST_TEMPLATE.format(
            sources_list=sources_list)
    return _ensure_image(args, cache_dir, 'build', args.architecture,
            top_tmp_dir,
            hook=HOOK_TEMPLATE.format(script=setup_sources_list))
