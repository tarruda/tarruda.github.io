import pathlib
import json

from ush.sh import chdir, mv, rm, yarnpkg, tar

from .config import cset
from .control import missing_description
from .generator_common import CommonGenerator


SECTION = 'debian.control.package.nodejs'

IMAGE_SETUP = '''
curl -sL https://deb.nodesource.com/setup_12.x | bash -
curl -sS https://dl.yarnpkg.com/debian/pubkey.gpg | apt-key add -
echo "deb https://dl.yarnpkg.com/debian/ stable main" > /etc/apt/sources.list.d/yarn.list
apt update
apt-get install -y nodejs yarn
'''

def makefile_contents():
    return (
            'all:\n'
            '\ttar xf node_modules.tgz\n'
            '\tmv node_modules files/\n'
            )


def get_install_dir(config):
    return 'usr/lib/nodejs/{}'.format(config['package']['name'])


class NodejsGenerator(CommonGenerator):
    def expand_config(self, config):
        super().expand_config(config)
        cset(config, 'scripts', 'image-setup.generator-nodejs', IMAGE_SETUP)
        name = config['package']['name']
        install_dir = get_install_dir(config)
        cset(config, 'debian.rules.override_dh_fixperms', 'recipe',
                'dh_fixperms --exclude {}'.format(install_dir))
        cset(config, SECTION, 'package', name)
        cset(config, SECTION, 'architecture', 'all')
        cset(config, SECTION, 'depends', 'nodejs, $${misc:Depends}')
        cset(config, 'debian.extra.install', 'filename', '{}.install'.format(name))
        cset(config, 'debian.extra.install', 'contents',
                'files/* {}\n'.format(install_dir))


    def copy(self, config):
        target_dir = config.target_dir
        name = config['package']['name']
        pkg_json = json.loads((target_dir / 'package.json').read_text())
        # read default description from package.json
        cset(config, SECTION, 'description', pkg_json.get('description',
            missing_description(name)))
        # setup symlinks for executables declared in package.json
        bins = pkg_json.get('bin', {})
        links_contents = []
        install_dir = get_install_dir(config)
        for prog in bins:
            script = pathlib.Path(install_dir) / bins[prog]
            links_contents.append('{} usr/bin/{}'.format(script, prog))
        cset(config, 'debian.extra.links', 'contents',
                '\n'.join(links_contents) + '\n')
        cset(config, 'debian.extra.links', 'filename', '{}.links'.format(name))
        # move everything into "files"
        temp_files_dir = target_dir.parent / 'files'
        mv('-v', target_dir, temp_files_dir)()
        target_dir.mkdir()
        mv('-v', temp_files_dir, target_dir)()
        with chdir(target_dir / 'files'):
            yarnpkg('install', '--prod')()
            tar('czf', 'node_modules.tgz', 'node_modules')()
            rm('-rf', 'node_modules')()
            mv('node_modules.tgz', '..')()
        makefile = target_dir / 'Makefile'
        makefile.write_text(makefile_contents())
        super().copy(config)


GENERATOR = NodejsGenerator()
