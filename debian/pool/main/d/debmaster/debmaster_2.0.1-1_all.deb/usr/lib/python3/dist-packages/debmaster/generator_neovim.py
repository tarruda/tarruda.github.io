import re

from ush.sh import mv

from .misc import dir_glob
from .config import cset
from .generator_common import CommonGenerator


POSTINST_TEMPLATE = '''#!/bin/sh -e

temp_home="$$(mktemp -d)"
if [ "$$1" = "configure" ] || [ "$$1" = "abort-remove" ]; then
  if [ -d {package_dir}/doc ]; then
    HOME="$$temp_home" /usr/bin/nvim >/dev/null 2>&1 +'helptags {package_dir}/doc' +q!
  fi
  mkdir -pv {package_dir}/plugin
  if [ "{is_remote_plugin}" = "yes" ]; then
    HOME="$$temp_home" NVIM_RPLUGIN_MANIFEST={package_dir}/plugin/rplugin_tmp.vim /usr/bin/nvim >/dev/null 2>&1 +'packadd {name}' +UpdateRemotePlugins +q!
    rm -rf "$$temp_home"
    cat > {package_dir}/plugin/rplugin_manifest.vim << "EOF"
if exists('g:loaded_remote_plugins_for_{package_id}')
  finish
endif
let g:loaded_remote_plugins_for_{package_id} = 1
EOF
    cat {package_dir}/plugin/rplugin_tmp.vim >> {package_dir}/plugin/rplugin_manifest.vim
    rm -f {package_dir}/plugin/rplugin_tmp.vim
  fi
fi
'''

PRERM_TEMPLATE = '''#!/bin/sh -e

if [ "$$1" = "remove" ] || [ "$$1" = "deconfigure" ]; then
  rm -f {package_dir}/doc/tags
  rm -f {package_dir}/plugin/rplugin_manifest.vim
  find {package_dir} -type f -name '*.pyc' -delete
  find {package_dir} -type d -name '__pycache__' | while read dir; do rm -rf $$dir; done
fi
'''


def generate_postinst(name, package_dir, is_remote_plugin):
    package_id = name.replace('-', '_')
    return POSTINST_TEMPLATE.format(**locals())


def generate_prerm(package_dir):
    return PRERM_TEMPLATE.format(**locals())


class NeovimGenerator(CommonGenerator):
    def expand_config(self, config):
        super().expand_config(config)
        name = config['package']['name']
        section = 'debian.control.package.nvim'
        cset(config, section, 'package', name)
        cset(config, section, 'architecture', 'all')
        cset(config, section, 'depends', 'neovim (>= 0.1.7), $${misc:Depends}')
        cset(config, section, 'recommends', 'python-neovim, python3-neovim')
        autostart = config.getboolean('generator', 'autostart', fallback=False)
        install_dir = '/usr/share/nvim/runtime/pack/dist/{}/{}'.format(
                'start' if autostart else 'opt', name)
        is_remote_plugin = 'yes' if config.getboolean('generator',
                'remote-plugin', fallback=False) else 'no'
        cset(config, 'debian.rules.override_dh_fixperms', 'recipe',
                'dh_fixperms --exclude {}'.format(install_dir))
        # generate install/postinst/prerm scripts
        cset(config, 'debian.extra.install', 'filename', name + '.install')
        cset(config, 'debian.extra.install', 'contents',
                'files/* {}\n'.format(install_dir))
        cset(config, 'debian.extra.postinst', 'filename', name + '.postinst')
        cset(config, 'debian.extra.postinst', 'contents', generate_postinst(
            name, install_dir, is_remote_plugin))
        cset(config, 'debian.extra.prerm', 'filename', name + '.prerm')
        cset(config, 'debian.extra.prerm', 'contents',
                generate_prerm(install_dir))


    def copy(self, config):
        target_dir = config.target_dir
        # move the extracted directory into the "files" sibling
        temp_files_dir = target_dir.parent / 'files'
        mv('-v', target_dir, temp_files_dir)()
        # recreate target_dir
        target_dir.mkdir()
        # move "files" into target_dir
        mv('-v', temp_files_dir, target_dir)()
        # dpkg-source -b will choke if the root of the debianized source has no
        # files
        (target_dir / 'README').touch()
        super().copy(config)


GENERATOR = NeovimGenerator()
