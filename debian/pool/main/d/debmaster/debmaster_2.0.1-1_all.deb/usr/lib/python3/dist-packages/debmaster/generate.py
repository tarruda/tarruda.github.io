import os
import pathlib
import stat
import subprocess
import sys

from ush import sh

sh.alias(
        dpkg_source='dpkg-source',
        )

from ush.sh import rm, cp, dpkg_source
        
from .misc import debug, dir_glob, directory_sha256, get_pkg_cache_dir
from .config import read_config
from .generator_dsc import GENERATOR as DSC_GENERATOR
from .generator_nodejs import GENERATOR as NODEJS_GENERATOR
from .generator_python import GENERATOR as PYTHON_GENERATOR
from .generator_neovim import GENERATOR as NEOVIM_GENERATOR
from .generator_common import GENERATOR as SIMPLE_GENERATOR
from .pbuilder import ensure_source_image


PBUILDER_SCRIPT_TEMPLATE = '''#!/bin/bash -e
groupadd -g {gid} debmaster
useradd -u {uid} -g {gid} --create-home debmaster
mv {top_tmp_dir}/debmaster-modules /usr/lib/python3/dist-packages/debmaster
mv /usr/lib/python3/dist-packages/debmaster/ush.py /usr/lib/python3/dist-packages
runuser -u debmaster -g debmaster -- python3 -m "debmaster.debmaster" {generate_args}
'''

def cache_source_package(config):
    pkg_cache_dir = get_pkg_cache_dir(config)
    if pkg_cache_dir.exists():
        rm('-rf', pkg_cache_dir)()
    src_pkg_cache_dir = pkg_cache_dir / 'src'
    src_pkg_cache_dir.mkdir(exist_ok=True, parents=True)
    sha256 = config.package_data['current_sha256']
    checksum_file = pkg_cache_dir / 'source_sha256'
    checksum_file.write_text(sha256)
    for f in dir_glob(config.tmp_dir, '*'):
        cp('-v', f, src_pkg_cache_dir, cwd=config.tmp_dir)()
    return pkg_cache_dir


def get_generator(config):
    return {
        'python': PYTHON_GENERATOR,
        'nodejs': NODEJS_GENERATOR,
        'neovim': NEOVIM_GENERATOR,
        'dsc': DSC_GENERATOR,
        'none': SIMPLE_GENERATOR
    }[config['generator'].get('type', 'none').lower()]


def inspect_package(config):
    generator = get_generator(config)
    generator.expand_config(config)
    return get_pkg_cache_dir(config), generator.is_outdated(config)


def generate_one(config):
    generator = get_generator(config)
    generator.generate(config)
    debug('processing', config.package_dir)
    dpkg_source('-b', config.target_dir.name, cwd=config.target_dir.parent)()
    rm('-rf', config.target_dir)()
    return cache_source_package(config), True


def required_modules():
    yield sys.modules['ush'].__file__
    package_dir = pathlib.Path(__file__).parent
    for pyscript in package_dir.glob('*.py'):
        yield str(pyscript)


def collect_setup_scripts(packages):
    scripts = set()
    for _, _, _, config in packages:
        if not config.has_section('scripts'):
            continue
        scripts_section = config['scripts']
        for k, v in scripts_section.items():
            if not k.startswith('image-setup.'):
                continue
            script = scripts_section[k].strip()
            if script:
                scripts.add(script)
    return scripts


def generate_with_pbuilder(args, cache_dir, top, top_tmp_dir, packages):
    setup_scripts = collect_setup_scripts(packages)
    pbuilder = ensure_source_image(args, cache_dir, top_tmp_dir, setup_scripts)
    modules_dir = top_tmp_dir / 'debmaster-modules'
    rm('-rf', modules_dir)()
    modules_dir.mkdir(parents=True)
    for f in required_modules():
        cp(f, modules_dir)()
    script = top_tmp_dir / 'main.sh'
    generate_args = [
        '--name="{}"'.format(args.name),
        '--email="{}"'.format(args.email),
        '--distribution="{}"'.format(args.distribution),
        '--release="{}"'.format(args.release),
        '--packages="{}"'.format(args.packages),
        '--in-pbuilder',
        '--directory={}'.format(top),
        '--cache-root={}'.format(cache_dir)
    ]
    script.write_text(
            PBUILDER_SCRIPT_TEMPLATE.format(
                top_tmp_dir=str(top_tmp_dir),
                generate_args=' '.join(generate_args),
                uid=os.getuid(), gid=os.getgid()))
    bindmounts = ' '.join(str(s) for s in [cache_dir, top, top_tmp_dir])
    pbuilder('execute')('--bindmounts', bindmounts, script)()


def iter_packages(args, cache_dir, top, top_tmp_dir):
    all_packages = args.packages.split(',')
    for package_dir in pathlib.Path(top).resolve().iterdir():
        if (args.packages != '*' and package_dir.name not in all_packages):
            continue
        if package_dir.name.startswith('.'):
            continue
        config_file = package_dir / 'debmaster.cfg'
        if config_file.is_file():
            config = read_config(args, config_file, package_dir, cache_dir,
                    top_tmp_dir)
            pkg_cache_dir, outdated = inspect_package(config)
            yield outdated, pkg_cache_dir, package_dir, config
        elif package_dir.is_dir():
            debug('no debmaster.cfg found in', package_dir, 'skipping it')


def generate(args, cache_dir, top, top_tmp_dir):
    packages = list(iter_packages(args, cache_dir, top, top_tmp_dir))
    has_outdated_packages = any(map(lambda x: x[0], packages))

    if args.in_pbuilder:
        for outdated, _, _, config in packages:
            if outdated:
                generate_one(config)
        # We're inside the pbuilder environment for generating source packages,
        # nothing left to do.
        sys.exit(0)
    elif has_outdated_packages:
        # use pbuilder to generate source packages
        generate_with_pbuilder(args, cache_dir, top, top_tmp_dir, packages)
    else:
        debug('no packages to generate')

    return packages
