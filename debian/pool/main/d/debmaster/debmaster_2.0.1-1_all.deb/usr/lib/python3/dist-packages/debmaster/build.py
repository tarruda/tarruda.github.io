import json
import os

from ush.sh import rm, cp, sudo

from .misc import debug
from .pbuilder import ensure_build_image


def is_outdated(config, pkg_cache_dir, package_dir):
    build_cache_dir = pkg_cache_dir / 'build'
    if not build_cache_dir.exists():
        return True
    cached_build_config = build_cache_dir / 'build-config.json'
    if not cached_build_config.exists():
        return True
    current_build_config = json.dumps(config._sections['build'],
            sort_keys=True)
    return current_build_config != cached_build_config.read_text().strip()


def build_one(args, cache_dir, top_tmp_dir, rebuilt, pkg_cache_dir,
        package_dir, config):
    if not is_outdated(config, pkg_cache_dir, package_dir):
        debug('skipped build', config.package_dir)
        return
    release = config['debmaster']['release']
    results_dir = config.tmp_dir
    dsc_file = list((pkg_cache_dir / 'src').glob('*.dsc'))[0]
    pbuilder = ensure_build_image(args, cache_dir, top_tmp_dir)
    build_cmd = pbuilder('build')('--buildresult', results_dir, dsc_file)
    deb_build_options = config.get('build', 'deb_build_options')
    if deb_build_options:
        build_cmd = build_cmd(env={'DEB_BUILD_OPTIONS': deb_build_options})
    build_cmd()
    build_cache_dir = pkg_cache_dir / 'build'
    rm('-rf', build_cache_dir)()
    build_cache_dir.mkdir(parents=True)
    if os.getuid() != 0:
        user_group = '{}:{}'.format(os.getuid(), os.getgid())
        # pbuilder-generated packages are owned by root. Change ownership or
        # the temporary directory won't be removed
        sudo('chown', '-R', user_group, '.',  cwd=results_dir, glob=True)()
    cp('*.deb', build_cache_dir, cwd=results_dir, glob=True)()
    cached_build_config = build_cache_dir / 'build-config.json'
    cached_build_config.write_text(
            json.dumps(config._sections['build'], sort_keys=True))


def build(args, cache_dir, packages, top_tmp_dir):
    for package in packages:
        build_one(args, cache_dir, top_tmp_dir, *package)
