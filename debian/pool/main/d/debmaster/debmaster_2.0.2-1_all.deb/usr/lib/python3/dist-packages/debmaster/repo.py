import json
import pathlib
import re

import ush 

from ush.sh import reprepro

from .misc import debug


def is_outdated(pkg_metadata, rebuilt, config):
    current_include_pattern = config.get('repo', 'include-pattern', raw=True)
    old_include_pattern = pkg_metadata.get('include-pattern')
    old_sha256 = pkg_metadata.get('sha256')
    up_to_date = (old_include_pattern == current_include_pattern and
            old_sha256 == config.package_data['current_sha256'] and
            not rebuilt)
    return not up_to_date


def update(args, reprepro_cmd, packages_metadata, rebuilt, pkg_cache_dir,
        package_dir, config):
    current_include_pattern = config.get('repo', 'include-pattern', raw=True)
    include_pattern = re.compile(current_include_pattern)
    for deb in (pkg_cache_dir / 'build').glob('*.deb'):
        if include_pattern.search(deb.name):
            reprepro_cmd('includedeb', args.release, deb)()
    if args.add_sources:
        reprepro_cmd('includedsc', args.release, dsc)()
    src_pkg_name = get_src_package_name(pkg_cache_dir)
    packages_metadata[src_pkg_name] = {
        'include-pattern': current_include_pattern,
        'sha256': config.package_data['current_sha256']
    }
    return True


def ensure_repository_config(args, output_repository):
    metadata_file = output_repository / 'debmaster-repo.json'
    config_dir = output_repository / args.distribution / 'conf'
    distributions = config_dir / 'distributions'
    options = config_dir / 'options'
    metadata = {
        'codenames': [],
        'sign-key': None
    }
    if metadata_file.exists():
        metadata = json.loads(metadata_file.read_text())
    codename_exists = args.release in metadata['codenames']
    sign_key_matches = metadata['sign-key'] == args.sign_key
    up_to_date = codename_exists and sign_key_matches
    if distributions.exists() and options.exists() and up_to_date:
        return config_dir
    metadata['sign-key'] = args.sign_key
    if args.release not in metadata['codenames']:
        metadata['codenames'].append(args.release)
    config_dir.mkdir(exist_ok=True, parents=True)
    conf_lines = []
    for codename in metadata['codenames']:
        conf_lines.extend([
            'Origin: debmaster',
            'Label: debmaster',
            'Codename: {}'.format(codename),
            'Architectures: i386 amd64 arm64 armhf source',
            'Components: main',
            'Description: Debmaster-generated repository',
        ])
        if args.sign_key:
            conf_lines.append('SignWith: {}'.format(args.sign_key))
        conf_lines.append('')
    distributions.write_text('\n'.join(conf_lines))
    metadata_file.write_text(json.dumps(metadata))
    return config_dir


def get_packages_metadata_file(output_repository):
    return output_repository / 'debmaster-packages.json'


def read_packages_metadata(output_repository):
    packages_metadata_file = get_packages_metadata_file(output_repository)
    if packages_metadata_file.exists():
        return json.loads(packages_metadata_file.read_text())
    return {}


def write_packages_metadata(packages_metadata, output_repository):
    packages_metadata_file = get_packages_metadata_file(output_repository)
    packages_metadata_file.write_text(json.dumps(packages_metadata, indent=2))


def get_src_package_name(pkg_cache_dir):
    source_packages = list((pkg_cache_dir / 'src').glob('*.dsc'))
    assert len(source_packages) == 1
    dsc = source_packages[0]
    src_package, _ = dsc.with_suffix('').name.split('_')
    return src_package


def cleanup_repository(args, reprepro_cmd, packages_metadata, packages):
    source_packages = set()
    outdated_packages = []
    to_remove = set()
    for package in packages:
        rebuilt, pkg_cache_dir, _, config = package
        pkg_metadata = packages_metadata.get(config['package']['name'], {})
        src_pkg_name = get_src_package_name(pkg_cache_dir)
        source_packages.add(src_pkg_name)
        if is_outdated(pkg_metadata, rebuilt, config):
            outdated_packages.append(package)
            to_remove.add(src_pkg_name)
    for src_pkg_name in reprepro_cmd('--list-format=${$source}\\n', 'list',
            args.release):
        if src_pkg_name not in source_packages:
            to_remove.add(src_pkg_name)
    for src_pkg_name in to_remove:
        if src_pkg_name in packages_metadata:
            del packages_metadata[src_pkg_name]
    if to_remove:
        condition = ' | '.join('$Source (== {})'.format(n) for n in to_remove)
        if args.verbose:
            print('removing packages matching condition', condition)
        reprepro_cmd('removefilter', args.release, condition)()
    return outdated_packages, to_remove


def reprepro_update(args, reprepro_cmd, packages_metadata, packages):
    reprepro_cmd = reprepro_cmd('--export=silent-never')
    outdated_packages, removed = cleanup_repository(args, reprepro_cmd,
            packages_metadata, packages)
    for package in outdated_packages:
        update(args, reprepro_cmd, packages_metadata, *package)
    return outdated_packages or removed


def update_repository(args, packages):
    output_repository = pathlib.Path(args.output_repository).resolve()
    config_dir = ensure_repository_config(args, output_repository)
    packages_metadata = read_packages_metadata(output_repository)
    repo_dir = config_dir.parent
    reprepro_cmd = reprepro
    if args.verbose:
        reprepro_cmd('-v')
    reprepro_cmd = reprepro_cmd('-b', repo_dir)
    if reprepro_update(args, reprepro_cmd, packages_metadata, packages):
        reprepro_cmd('export', args.release)()
    write_packages_metadata(packages_metadata, output_repository)
