import collections
import re

RULE_SECTION = re.compile(r'^debian\.rules\.(.+)$')
RECIPE_WITH_TABS = re.compile(r'^\t', re.MULTILINE)
def ensure_rules(config):
    rules = config.target_dir / 'debian' / 'rules'
    if rules.exists():
        return

    data = ['#!/usr/bin/make -f']
    for section in config.sections():
        m = RULE_SECTION.match(section)
        if not m:
            continue
        if config.has_option(section, 'prefix'):
            data.append(config.get(section, 'prefix'))
        rule_name = m.group(1)
        rule_deps = config.get(section, 'deps', fallback='')
        first_line = rule_name + ':'
        if rule_deps:
            first_line += ' ' + rule_deps
        data.append(first_line)
        recipe = config.get(section, 'recipe', fallback='')
        if RECIPE_WITH_TABS.match(recipe):
            # The recipe is already formatted with tabs (from parsed rules
            # file), so just append it.
            data.append(('\t' + recipe) if recipe[0] != '\t' else recipe)
        elif recipe:
            for recipe_line in recipe.split('\n'):
                data.append('\t' + recipe_line)
        if config.has_option(section, 'suffix'):
            data.append(config.get(section, 'suffix'))
    rules.write_text('\n'.join(data) + '\n')


# "simple" regexp for extracting targets/deps/recipes out of debian/rules
# Makefile. Everything that is not captured, is considered part of the rule
# prefix.
RULE = re.compile(r'''
       ^
       (?P<rule>               # rule name
         [^#"': \t\n]+
         [ \t]*
       )
       :                       # colon
       (?![=])                 # not followed by equals sign (assign)
       [ \t]*                  # optionally followed by spaces
       (?P<deps>
         (?:\\\n|[^\n;])*      # everything until a semicolon or unescaped line
       )
       [\n;]
       (?P<recipe>
         (?:
           (?!
             (?<=[^\\]\n)      # recipe ends after an unescaped line
             (?!
               \t              # unless the character is a tab
               |
               (?:             # or starts a conditional block eventually
                 (?:           # followed by a tab
                   (?:
                   ifeq|ifneq|ifdef|ifndef|else
                   )
                   \b
                   [^\n]*
                   \n
                 )?            # or is simply a bunch of comments/empty lines
                               # eventually followed by a tab
                 (?:(?:[#][^\n]*)?\n)*
                 \t
               )
               |
               endif\b         # or ends a conditional
             )
           )
           .
         )*
       )
''', re.VERBOSE | re.DOTALL | re.MULTILINE)

def parse_rules(rules):
    # remove shebang line
    rules = '\n'.join(rules.split('\n')[1:])
    rv = collections.OrderedDict()
    pos = 0
    rule_name = None
    for match in RULE.finditer(rules):
        start, end = match.span()
        rule_name = match.group('rule')
        rv[rule_name] = {
            'prefix': rules[pos:start].strip() if start != pos else None,
            'deps': match.group('deps').strip(),
            # strip trailing line from recipe
            'recipe': match.group('recipe')[:-1]
        }
        pos = end
    if pos != len(rules):
        rv[rule_name]['suffix'] = rules[pos:len(rules)]
    return rv

if __name__ == '__main__':
    with open('/home/tarruda/rules') as f:
        parse_rules(f.read())
