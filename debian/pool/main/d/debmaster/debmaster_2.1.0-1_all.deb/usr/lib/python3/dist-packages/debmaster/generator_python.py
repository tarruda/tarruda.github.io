import configparser
import subprocess
import sys

from .config import cset
from .control import missing_description
from .generator_common import CommonGenerator


IMAGE_SETUP = '''
apt install -y python-setuptools python3-setuptools
'''

def read_description(package, target_dir):
    fallback = missing_description(package)
    parser = configparser.ConfigParser(interpolation=None, strict=False)
    for d in target_dir.glob('*.egg-info'):
        pkg_info = d / 'PKG-INFO'
        if not pkg_info.exists():
            continue
        parser.read_string('[DEFAULT]\n' + pkg_info.read_text())
        return parser.get('DEFAULT', 'summary', fallback=fallback)
    return fallback


def get_python_version_info(config):
    py2 = config.getboolean('generator', 'python2', fallback=True)
    py3 = config.getboolean('generator', 'python3', fallback=True)
    if not (py2 or py3): 
        raise Exception('Python package cannot disable both python 2 and 3')

    pythons = []
    if py2:
        pythons.append('python2')
    if py3:
        pythons.append('python3')
    return py2, py3, pythons


class PythonGenerator(CommonGenerator):
    def expand_config(self, config):
        super().expand_config(config)
        cset(config, 'scripts', 'image-setup.generator-python', IMAGE_SETUP)
        py2, py3, pythons = get_python_version_info(config)
        name = config['package']['name']
        pybuild_name = config.get('generator', 'pybuild_name', fallback=name)

        # use pybuild as the debian/rules buildsystem
        cset(config, 'debian.rules.%', 'prefix',
                'export PYBUILD_NAME={}'.format(pybuild_name))
        cset(config, 'debian.rules.%', 'recipe',
                'dh $$@ --with {} --buildsystem=pybuild'.format(','.join(pythons)),
                override=True)

        extra_build_deps = ', dh-python'
        if py2:
            extra_build_deps += ', python-setuptools, python-all'
        if py3:
            extra_build_deps += ', python3-setuptools, python3-all'

        # add some extra packages to build-depends
        cset(config, 'debian.control.source', 'build-depends +',
                extra_build_deps)

        # add package sections to control
        for python in pythons:
            section = 'debian.control.package.{}'.format(python)
            prefix = 'python3' if python == 'python3' else 'python'
            cset(config, section, 'package', '{}-{}'.format(prefix, name))
            # TODO detect if the package has extension modules. If so, the
            # architecture should be "any" and build-depends above should be
            # python-all-dev
            cset(config, section, 'architecture', 'all')
            cset(config, section, 'depends',
                    '$${misc:Depends}, $${' + prefix + ':Depends}')


    def unpack(self, config):
        super().unpack(config)
        py2, py3, pythons = get_python_version_info(config)
        # generate egg-info directory since it must be part of the source
        # distribution for dh_python
        egg_info_argv = [sys.executable, 'setup.py', 'egg_info']
        if not py3:
            # when the package specifies python3=false, assume the possibility that
            # the setup.py file is incompatible with python3, so don't use
            # sys.executable.
            egg_info_argv[0] = 'python2'
        subprocess.check_call(egg_info_argv, cwd=str(config.target_dir))
        # read description from pkg-info
        description = read_description(config['package']['name'],
                config.target_dir)
        for python in pythons:
            section = 'debian.control.package.{}'.format(python)
            cset(config, section, 'description', description)


GENERATOR = PythonGenerator()
