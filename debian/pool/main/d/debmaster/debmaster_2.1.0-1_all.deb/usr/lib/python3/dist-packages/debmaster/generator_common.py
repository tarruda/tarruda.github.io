import datetime
import json
import re
import os

from ush.sh import cp, date, tar, debchange

from .config import cset
from .control import ensure_control
from .download import download_git
from .rules import ensure_rules
from .misc import dir_glob, directory_sha256, get_pkg_cache_dir, run_script


def create_orig_tarball(config):
    if not config.target_dir.exists():
        config.target_dir.mkdir(parents=True)
        return
    name = config['package']['name']
    orig_tarball = '{}_{}.orig.tar.gz'.format(name,
            # take the version from the "package" section to allow the user
            # overriding the version string. if the user didn't set a version,
            # it will be taken from upstream.version (automatically set by the
            # download handler)
            config['package']['version'])
    tar('cvzf', '../{}'.format(orig_tarball), '.', cwd=config.target_dir)()


def get_author(config):
    name = config['package']['author_name']
    email = config['package']['author_email']
    if email:
        return '{} <{}>'.format(name, email)
    return name


def record_changes(config):
    changes = []
    for change in config.get('package', 'changes', fallback='').split('\n'):
        change = change.strip()
        if change:
            changes.append(change)
    if not changes:
        return
    changelog = config.target_dir / 'debian' / 'changelog'
    if changelog.exists():
        debchange('--package', config['package']['name'], '--increment',
                changes[0], cwd=config.target_dir)()
    else:
        non_native = config.has_section('upstream')
        revision = '-1' if non_native else ''
        debchange('--create', '--package', config['package']['name'],
                '--newversion', config['package']['version'] + revision,
                changes[0], cwd=config.target_dir)()
    for change in changes[1:]:
        debchange(change, cwd=config.target_dir)()
    changelog_release = '{}-debmaster'.format(config['debmaster']['release'])
    debchange('--release', '--distribution', changelog_release,
            '--force-distribution', '', cwd=config.target_dir)()


def ensure_copyright(config):
    copyright = config.target_dir / 'debian' / 'copyright'
    if copyright.exists():
        return
    pattern = re.compile('LICENSE', re.IGNORECASE)
    license_file = None
    for f in config.target_dir.iterdir():
        if f.is_file() and pattern.search(str(f.name)):
            license_file = f
    if license_file:
        cp('-v', license_file, copyright)()
        return
    name = config['package']['name']
    non_native = config.has_section('upstream')
    url = config['upstream']['url'] if non_native else 'https://debian.org'
    year = datetime.datetime.now().year
    author = get_author(config)
    copyright.write_text('\n'.join((
        ('Format: '
         'http://www.debian.org/doc/packaging-manuals/copyright-format/1.0/'),
        'Upstream-Name: {name}',
        'Source: {url}',
        '',
        'Files: *',
        'Copyright: (c) {year} {author}',
        'License: LGPL-3',
        '',
        'License: LGPL-3',
        ' This file is licensed under the LGPL3.',
        ' .',
        (' On Debian systems, the complete text of the GNU Lesser Public '
         'License Version'),
        ' 3 can be found in ‘/usr/share/common-licenses/LGPL-3’.\n'
    )).format(name=name, url=url, year=year, author=author))


def ensure_compat(config):
    compat = config.target_dir / 'debian' / 'compat'
    if not compat.exists():
        compat.write_text('9\n')


def ensure_source_format(config):
    debian_source = config.target_dir / 'debian' / 'source'
    debian_source.mkdir(exist_ok=True, parents=True)
    source_format = debian_source / 'format'
    if not source_format.exists():
        non_native = config.has_section('upstream')
        if non_native:
            source_format.write_text('3.0 (quilt)')
        else:
            source_format.write_text('3.0 (native)')


def add_extra_files(config):
    for section in config.sections():
        if not section.startswith('debian.extra.'):
            continue
        fpath = config.target_dir / 'debian' / config.get(section, 'filename')
        fpath.write_text(config.get(section, 'contents').strip() + '\n')


def compute_package_dir_sha256(config, extra_data=None):
    config_sections = json.loads(json.dumps(config._sections))
    # for determining if the config file is outdated, don't include build/repo
    # sections since these only affect later optional stages
    for key in ['build', 'repo']:
        if key in config_sections:
            del config_sections[key]
    extra_checksum_data = json.dumps(config_sections, sort_keys=True)
    extra_checksum_data += extra_data or ''
    exclude = ['*~', '*.swp', '*.swo', 'debmaster.cfg', 'debmaster-*.cfg']
    return directory_sha256(config.package_dir, exclude='\n'.join(exclude),
            extra_checksum_data=extra_checksum_data)


class CommonGenerator(object):
    def is_outdated(self, config, extra_data=None):
        distribution = config['debmaster']['distribution']
        release = config['debmaster']['release']
        name = config['package']['name']
        sha256 = get_pkg_cache_dir(config) / 'source_sha256'
        config.package_data['current_sha256'] = compute_package_dir_sha256(
                config, extra_data)
        if not sha256.exists():
            return True
        cached_sha256 = sha256.read_text().strip()
        return cached_sha256 != config.package_data['current_sha256']


    def expand_config(self, config):
        section = 'debian.control.source'
        cset(config, section, 'source', '${package:name}')
        cset(config, section, 'section', 'utils')
        cset(config, section, 'priority', 'extra')
        cset(config, section, 'maintainer',
                '${package:author_name} <${package:author_email}>')
        cset(config, section, 'build-depends', 'debhelper (>= 9)')
        cset(config, section, 'standards-version', '3.9.8')
        if config.has_section('upstream'):
            cset(config, section, 'homepage', '${upstream:url}')
        cset(config, 'debian.rules.%', 'recipe', 'dh $$@ --parallel')
        cset(config, 'package', 'changes', 'Initial release.') 


    def unpack(self, config):
        if config.has_section('upstream'):
            download_handler = {
                'git': download_git
            }.get(config['upstream']['type'])
            download_handler(config)


    def copy(self, config):
        exclude_patterns = (
                config['copy'].get('exclude') +
                '\ndebmaster.cfg' +
                '\ndebmaster-*.cfg'
        )
        for f in dir_glob(config.package_dir, config['copy'].get('pattern'),
                exclude_patterns):
            target = config.target_dir / f
            target.parent.mkdir(exist_ok=True, parents=True)
            cp('-v', config.package_dir / f, target)()


    def debianize(self, config):
        create_orig_tarball(config)
        debian_dir = config.target_dir / 'debian'
        debian_dir.mkdir(exist_ok=True, parents=True)
        ensure_control(config)
        ensure_rules(config)
        add_extra_files(config)
        record_changes(config)
        ensure_copyright(config)
        ensure_compat(config)
        ensure_source_format(config)


    def generate(self, config):
        self.unpack(config)
        run_script(config, 'after-unpack')
        self.copy(config)
        run_script(config, 'after-copy')
        self.debianize(config)
        run_script(config, 'after-debianize')


GENERATOR = CommonGenerator()
