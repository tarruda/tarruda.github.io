import configparser
import os
import re
import textwrap

from .misc import debug

DEFAULT_CONFIG = '''
[package]
name = ${debmaster:package_name}
version = ${upstream:version}
author_name = ${debmaster:author_name}
author_email = ${debmaster:author_email}

[generator]
type = none

[copy]
pattern = **/*
exclude =
    *~

[build]
deb_build_options = nocheck

[repo]
include-pattern = ^.+\.deb$
'''


PREFIX = re.compile(r'\|\s')
def remove_multiline_value_prefix(value):
    # Remove the leading prefix and common leading whitespace from continuation
    # lines.
    lines = value.split('\n')
    first_line = lines[0]
    continuation_lines = lines[1:]
    for i, line in enumerate(continuation_lines):
        if PREFIX.match(line):
            continuation_lines[i] = continuation_lines[i][1:]
    rv = first_line + '\n' + textwrap.dedent('\n'.join(continuation_lines))
    return rv.rstrip()


NONSPACE = re.compile(r'\S')
def add_multiline_value_prefix(fp):
    for line in fp:
        first_nonspace = NONSPACE.search(line)
        if first_nonspace and first_nonspace.start() > 0:
            # Continuation line, prepend a nonspace char to prevent
            # configparser from stripping leading spaces
            yield ' |' + line
        else:
            yield line


class DebmasterInterpolation(configparser.ExtendedInterpolation):
    _CONDITIONAL_SECTION = re.compile(r'^(\w+)(==|!=)([^:]+):(.+)$')
    _KEY_TRANSFORM = re.compile(r' [+-s]$')
    _VALID_SEPCHARS = re.compile(r'^[!@#$%^&*]$')

    def __init__(self):
        self._transforms = {}
        self._conditional_overrides = []
        self._deletes = []

    def before_get(self, parser, section, option, value, defaults):
        transform_key = (section, option)
        if transform_key in self._transforms:
            for operator, transform in self._transforms[transform_key]:
                if operator == '+':
                    value += transform
                elif operator == '-':
                    value = value.replace(transform, '')
                elif operator == 's':
                    sepchar = transform[0]
                    if not self._VALID_SEPCHARS.match(sepchar):
                        raise Exception(
                                'invalid substitute separator char {}'.format(
                                    sepchar))
                    pattern, repl, count = transform[1:].split(sepchar)
                    value = re.sub(pattern, repl, value,
                            count=int(count) if count else 0)
                else:
                    raise Exception('invalid operator {}'.format(operator))
        return super().before_get(parser, section, option, value, defaults)

    def _handle_conditional(self, section, option, value):
        m = self._CONDITIONAL_SECTION.match(section)
        if not m:
            return False
        left_side = m.group(1)
        operator = m.group(2)
        right_ride = m.group(3)
        orig_section = m.group(4)
        self._conditional_overrides.append((
            left_side, operator, right_ride, orig_section, option, value
        ))
        return True

    def _handle_transform(self, section, option, value):
        if self._KEY_TRANSFORM.search(option):
            transform_key = (section, option[:-1].strip())
            if transform_key not in self._transforms:
                self._transforms[transform_key] = []
            self._transforms[transform_key].append((option[-1], value))
            self._deletes.append((section, option))
            return True
        return False

    def before_set(self, parser, section, option, value):
        if self._handle_conditional(section, option, value):
            return None
        if self._handle_transform(section, option, value):
            return None
        return super().before_set(parser, section, option, value)

    def before_read(self, parser, section, option, value):
        value = remove_multiline_value_prefix(value)
        if self._handle_conditional(section, option, value):
            return None
        if self._handle_transform(section, option, value):
            return None
        return super().before_read(parser, section, option, value)


class DebmasterConfig(configparser.ConfigParser):
    def __init__(self, args, package_dir, cache_dir, top_tmp_dir):
        super().__init__(interpolation=DebmasterInterpolation())
        self.package_data = {}
        self.package_dir = package_dir
        self.cache_dir = cache_dir
        self.tmp_dir = top_tmp_dir / package_dir.name
        self.target_dir = self.tmp_dir / 'src'
        # setup some initial values
        self.add_section('debmaster')
        self['debmaster']['package_name'] = package_dir.name
        setup_author_name(args, self)
        setup_author_email(args, self)
        setup_distribution(args, self)
        setup_release(args, self)

    def _clear_transforms(self):
        for section, option in self._interpolation._deletes:
            self.remove_option(section, option)
        self._interpolation._deletes = []

    def _process_conditional_override(self, lside, op, rside, orig_section,
            option, value):
        actual_value = self.get('debmaster', lside, fallback=None)
        if actual_value is None:
            debug('condition checking for missing key "{}"'.format(lside))
            return False
        override = (op == '==' and actual_value == rside) or (
                    op == '!=' and actual_value != rside)
        if override:
            debug('overriding {}.{} with {} due to condition'.format(
                orig_section, option, value), lside, op, rside)
            self.set(orig_section, option, value)

    def _process_conditional_overrides(self):
        for override in self._interpolation._conditional_overrides:
            self._process_conditional_override(*override)
        self._interpolation._conditional_overrides = []

    def set(self, section, option, value=None):
        rv = super().set(section, option, value)
        self._clear_transforms()
        return rv

    def _read(self, fp, fpname):
        rv = super()._read(add_multiline_value_prefix(fp), fpname)
        self._clear_transforms()
        self._process_conditional_overrides()
        return rv

    @property
    def transform_options(self):
        return self._interpolation._transforms.keys()


def cset(config, section, option, value, override=False):
    if not config.has_section(section):
        config.add_section(section)
    if not override and option in config[section]:
        return
    config.set(section, option, value)


def setup_author_name(args, config):
    config['debmaster']['author_name'] = args.name


def setup_author_email(args, config):
    config['debmaster']['author_email'] = args.email


def setup_distribution(args, config):
    config['debmaster']['distribution'] = args.distribution


def setup_release(args, config):
    config['debmaster']['release'] = args.release


def read_config(args, config_file, package_dir, cache_dir, top_tmp_dir):
    config = DebmasterConfig(args, package_dir, cache_dir, top_tmp_dir)
    config.read_string(DEFAULT_CONFIG)
    config.read(str(config_file))
    directory = config_file.parent
    for extra_config_file in directory.glob('debmaster-*.cfg'):
        config.read(str(extra_config_file))
    return config
