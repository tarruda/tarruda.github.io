import fnmatch
import hashlib
import sys

from ush.sh import sha256sum, echo, dash


def debug(*args):
    print(*args, file=sys.stderr)


def compile_excluded(patterns):
    if not patterns:
        return lambda f: False
    rules = []
    for p in map(lambda p: p.strip(), patterns.split('\n')):
        if p:
            rules.append(lambda f, p=p: fnmatch.fnmatch(str(f), p))
    return lambda f: any(r(f) for r in rules)


def run_script(config, name):
    script = config.get('scripts', name, fallback=None)
    if script:
        (echo(script) | dash('-e', cwd=config.target_dir))()


def dir_glob(directory, patterns, exclude_patterns=None):
    excluded = compile_excluded(exclude_patterns)
    for pattern in (p for p in patterns.split('\n') if p):
        for f in directory.glob(pattern):
            if f.is_file():
                rel_file = f.relative_to(directory)
                if not excluded(rel_file):
                    yield rel_file


def directory_sha256(directory, exclude=None, extra_checksum_data=None):
    files = list(dir_glob(directory, '**/*', exclude))
    checksum = hashlib.sha256()
    if files:
        checksum.update(bytes(sha256sum(*files, cwd=directory)))
    if extra_checksum_data:
        checksum.update(extra_checksum_data.encode('utf8'))
    return checksum.hexdigest()


def get_pkg_cache_dir(config):
    distribution = config['debmaster']['distribution']
    release = config['debmaster']['release']
    name = config['package']['name']
    return config.cache_dir / 'packages' / distribution / release / name
