#!/bin/sh

_osroot="$(getarg rd.osroot.path)"

if [ -n "$_osroot" ]; then
	# move $NEWROOT to /run/fsroot, so it will be available after boot, but make it
	# accessible only by root
	mkdir /run/fsroot
	mount --bind $NEWROOT /run/fsroot
	umount $NEWROOT
	mount --bind "/run/fsroot/$_osroot" $NEWROOT
fi

unset _osroot
